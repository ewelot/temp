#!/bin/bash

# startup.sh
#
# to get started on AIRTOOLS v1.0 using sample observations
# data from 2016-02-24
# see also project page at https://github.com/ewelot/airtools
#
# T. Lehmann, Apr. 2016


# environment variables
export day=160224
export AI_SITE=Mayhill
export AI_RAWDIR=./
export AI_TMPDIR=/tmp

# load AIRTOOLS shell functions
. airfun.sh

# add some data to header file
set_header co01.head AI_TELID=T14 AI_NPA=90 AI_TRAIL=8
get_mpcephem -w co01

# start GUI
AIexamine co01.pgm co01_cs.pgm &

# Ready to play ...
# Good luck!

